

function fposts(v) {

    return `



        <p><span style="background-color: rgb(228, 220, 235);">Title:</span>&emsp; <span
                style="background-color: rgb(236, 204, 210);">
                ${v.title}</span></p>

        <p><span style="background-color: rgb(228, 220, 235);">Body:</span>&emsp; <span
                style="background-color: rgb(236, 204, 210);">
                ${v.body}</span></p>



        <br>



        `;
    }
    
    